//
//  ViewController.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-03-27.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import UIKit
import AVFoundation
import MobileCoreServices
import Firebase

class TracksViewController: UIViewController {
    
    var userID: String?
    
    var projectKey: String?
    
    var trackAmount: Int?
    
    var dict = [String : Any]()
    
    var tracks = [Track]()
    
    var ref: DatabaseReference!
    
    var projectRef: DatabaseReference!
    
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var goBackToStartButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var timeSlider: UISlider!
    
    
    @IBOutlet weak var eqcompView: UIView!
    @IBOutlet weak var knob1: Knob!
    @IBOutlet weak var knob2: Knob!
    @IBOutlet weak var knob3: Knob!
    @IBOutlet weak var knob4: Knob!
    @IBOutlet weak var knob5: Knob!
    @IBOutlet weak var knob6: Knob!
    @IBOutlet weak var knob7: Knob!
    @IBOutlet weak var knob8: Knob!
    
    @IBOutlet weak var knob1ValueLabel: UILabel!
    @IBOutlet weak var knob2ValueLabel: UILabel!
    @IBOutlet weak var knob3ValueLabel: UILabel!
    @IBOutlet weak var knob4ValueLabel: UILabel!
    @IBOutlet weak var knob5ValueLabel: UILabel!
    @IBOutlet weak var knob6ValueLabel: UILabel!
    @IBOutlet weak var knob7ValueLabel: UILabel!
    @IBOutlet weak var knob8ValueLabel: UILabel!
    
    @IBOutlet weak var trackName: UILabel!
    
    
    var knobs: [Knob] = []
    
    
    var audioEngine: AVAudioEngine = AVAudioEngine()
    var mixer: AVAudioMixerNode = AVAudioMixerNode()
    var audioPlayers = [AVAudioPlayerNode?]()
    var equalizers = [AVAudioUnitEQ]()
    
    var soloIndexPath = [IndexPath?](repeating: nil, count: 6)
    
    var startSeconds: Int64!
    var currentSeconds: Int64!
    
    var filesArray = [AVAudioFile?](repeating: nil, count: 5)
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        setupAudioEngine()
    }
    
    //MARK: VIEWDIDLOAD
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        print(projectKey)
        
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.collectionViewLayout = flowLayout
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(cellTapped(_:)))
        collectionView.addGestureRecognizer(tapGestureRecognizer)
        
        timeSlider.value = 0
        
        eqcompView.layer.borderWidth = 5
        eqcompView.layer.borderColor = UIColor.darkGray.cgColor
        
        setupKnobs()
        
        knobs = [knob1, knob2, knob3, knob4, knob5, knob6, knob7, knob8]
        //disable knobs
        disableKnobs()
        
    }
    
    var index: IndexPath!
    
    //MARK: CELL TAPPED
    
    @objc func cellTapped(_ sender: UITapGestureRecognizer) {
        let pointInCollectionView = sender.location(in: collectionView)
        let indexPath = collectionView.indexPathForItem(at: pointInCollectionView)
        index = indexPath
        print(index ?? 0)
        if let indexPath = indexPath {
            trackName.text = "Track \(indexPath.row + 1)"
            if let cell = collectionView.cellForItem(at: indexPath) as? TrackCell {
                if cell.audioPlayer == nil {
                    disableKnobs()
                } else {
                    enableKnobs()
                }
            } else {
                print("index nil")
            }
        } else {
            trackName.text = "Select a Track"
        }
    }
    
    
    @IBAction func knob1ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[0].frequency = knob1.value
        knob1ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[0].frequency))"
        print(self.equalizers[self.index.row].bands[0].frequency)
    }
    
    @IBAction func knob2ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[1].frequency = knob2.value
        knob2ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[1].frequency))"
        print(self.equalizers[self.index.row].bands[1].frequency)
    }
    
    @IBAction func knob3ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[2].frequency = knob3.value
        knob3ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[2].frequency))"
        print(self.equalizers[self.index.row].bands[2].frequency)
    }
    
    
    @IBAction func knob4ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[3].frequency = knob4.value
        knob4ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[3].frequency))"
        print(self.equalizers[self.index.row].bands[3].frequency)
    }
    
    
    @IBAction func knob5ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[0].gain = knob5.value
        knob5ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[0].gain))"
        print(self.equalizers[self.index.row].bands[0].gain)
    }
    
    
    @IBAction func knob6ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[1].gain = knob6.value
        knob6ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[1].gain))"
        print(self.equalizers[self.index.row].bands[1].gain)
    }
    
    
    @IBAction func knob7ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[2].gain = knob7.value
        knob7ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[2].gain))"
        print(self.equalizers[self.index.row].bands[2].gain )
    }
    
    
    @IBAction func knob8ValueChanged(_ sender: Any) {
        self.equalizers[self.index.row].bands[3].gain = knob8.value
        knob8ValueLabel.text = "\(Int(self.equalizers[self.index.row].bands[3].gain))"
        print(self.equalizers[self.index.row].bands[3].gain )
    }
    
    func removeAudioPlayer(audioPlayer: AVAudioPlayerNode) {
        DispatchQueue.global(qos: .background).async {
            self.audioEngine.detach(audioPlayer)
            print("EQ's: \(String(describing: self.equalizers))")
            print("Track's: \(String(describing: self.audioPlayers))")
        }
    }
    
//    func addAudioPlayer(audioPlayer: AVAudioPlayerNode) {
//        DispatchQueue.global(qos: .background).async {
//
//            let equalizer = AVAudioUnitEQ(numberOfBands: 4)
//
//            self.setupEQ(equalizer: equalizer)
//
//            self.audioEngine.attach(audioPlayer)
//            print("AUDIO PLAYER: \(audioPlayer)")
//            self.audioEngine.attach(equalizer)
//
//            self.audioEngine.connect(audioPlayer, to: equalizer, format: nil)
//            self.audioEngine.connect(equalizer, to: self.mixer, format: nil)
//
//            self.audioPlayers.insert(audioPlayer, at: self.index.row)
//            self.equalizers.insert(equalizer, at: self.index.row)
//            print("EQ's: \(String(describing: self.equalizers))")
//            print("Track's: \(String(describing: self.audioPlayers))")
//
//            print("PAN VALUE: \(audioPlayer.pan)")
//            print("VOLUME VALUE: \(audioPlayer.volume)")
//
//            DispatchQueue.main.async {
//                self.enableKnobs()
//            }
//        }
//    }
    
    func attachFiles(audioFile: URL) {
        let fileURL = audioFile
        
        var file: AVAudioFile!
        
        do {
            try file = AVAudioFile(forReading: (fileURL.absoluteURL))
            print(file.length)
            filesArray.insert(file, at: self.index.row)
            print("FILES: \(String(describing: filesArray))")
            scheduleFiles()
        } catch let error {
            print("File Error: \(error.localizedDescription)")
        }
    }
    
    func playTracks() {
        DispatchQueue.global(qos: .background).async {
            for (index, audioPlayer) in self.audioPlayers.enumerated() {
                audioPlayer?.play(at: nil)
                audioPlayer?.pan = self.tracks[index].pan!
                print("PAN: \(audioPlayer?.pan)")
                audioPlayer?.volume = self.tracks[index].volume!
                print("VOLUME: \(audioPlayer?.volume)")
                print("Playing")
            }
        }
    }
    
    func pauseAudioEngine() {
        audioEngine.pause()
        playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
    }
    
    @IBAction func playButtonTapped(_ sender: Any) {
        playButton.isSelected = !playButton.isSelected
        if playButton.isSelected {
            do {
                try audioEngine.start()
                let sampleTime = audioEngine.outputNode.lastRenderTime?.sampleTime
                let sampleRate = audioEngine.outputNode.outputFormat(forBus: 0).sampleRate
                startSeconds =  sampleTime! / AVAudioFramePosition(sampleRate)
                print(startSeconds ?? 0)
            } catch {
                print("Could not start audio engine")
            }
            playTracks()
            playButton.setBackgroundImage(UIImage(systemName: "stop"), for: .normal)
            playButton.isSelected = true
        } else {
            playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
            playButton.isSelected = false
            audioEngine.pause()
            
            for audioPlayer in audioPlayers {
                audioPlayer?.pause()
            }
        }
    }
    
    @IBAction func goBackButtonTapped(_ sender: Any) {
        DispatchQueue.global(qos: .background).async {
            self.audioEngine.stop()
            do {
                try self.audioEngine.start()
            } catch {
                print(error)
            }
            for audioPlayer in self.audioPlayers {
                audioPlayer?.stop()
            }
            self.scheduleFilesToStart()
            DispatchQueue.main.async {
                self.playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
                self.playButton.isSelected = false
            }
        }
    }
    
    @IBAction func timeSliderValueChanged(_ sender: Any) {
        if audioEngine.isRunning {
            let sampleTime = audioEngine.outputNode.lastRenderTime?.sampleTime
            let sampleRate = audioEngine.outputNode.outputFormat(forBus: 0).sampleRate
            currentSeconds =  sampleTime! / AVAudioFramePosition(sampleRate)
            print(currentSeconds ?? 0)
        }
    }
    
    func checkMuteTrack(cell: TrackCell) {
        if cell.isMuted == true {
            cell.muteDelegate?.muteButtonTapped(cell: cell)
            cell.audioPlayer?.volume = 0
            cell.muteButton.backgroundColor = .muteBlue
            cell.muteButton.tintColor = .muteBlue
            cell.volumeDelegate?.changeVolume(cell: cell, volume: cell.audioPlayer?.volume ?? 0)
        } else {
            cell.muteButton.isSelected = false
            cell.audioPlayer?.volume = cell.volumeSlider.value
            cell.muteButton.backgroundColor = .clear
            cell.muteButton.tintColor = .clear
            cell.volumeDelegate?.changeVolume(cell: cell, volume: cell.audioPlayer?.volume ?? 0)
        }
    }
    
}
