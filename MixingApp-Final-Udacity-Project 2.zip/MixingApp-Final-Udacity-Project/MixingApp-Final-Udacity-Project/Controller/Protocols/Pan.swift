//
//  Pan.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Pan {
    
    func changePan(cell: TrackCell, pan: Float) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Changed Pan for Track \(indexPath?.row ?? 0) to \(pan)")
        print(projectRef ?? "nil")
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["pan" : pan])
    }
    
}
