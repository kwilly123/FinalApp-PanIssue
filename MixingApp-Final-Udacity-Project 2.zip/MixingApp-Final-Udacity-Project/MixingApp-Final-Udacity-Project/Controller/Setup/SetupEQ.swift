//
//  SetupEQ.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation
import AVFoundation

extension TracksViewController {
    
    func setupEQ(equalizer: AVAudioUnitEQ) {
        equalizer.bands[0].filterType = .lowShelf
        equalizer.bands[0].bypass = false
        equalizer.bands[0].bandwidth = 2.0
        equalizer.bands[1].filterType = .parametric
        equalizer.bands[1].bypass = false
        equalizer.bands[1].bandwidth = 2.0
        equalizer.bands[2].filterType = .parametric
        equalizer.bands[2].bypass = false
        equalizer.bands[2].bandwidth = 2.0
        equalizer.bands[3].filterType = .highShelf
        equalizer.bands[3].bypass = false
        equalizer.bands[3].bandwidth = 2.0
    }
    
}
